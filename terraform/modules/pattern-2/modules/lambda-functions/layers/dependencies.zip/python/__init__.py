# Pattern 2 Dependencies Layer
